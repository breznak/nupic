from enthought.traits.api import HasTraits, Str

class Other(HasTraits):
    
    name = Str